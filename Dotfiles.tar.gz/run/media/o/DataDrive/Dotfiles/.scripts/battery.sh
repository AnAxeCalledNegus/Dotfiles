Key=-1

while true
do
	sleep 0.5
	BAT=$(cat /sys/class/power_supply/BAT0/capacity | tr -d '\n\r ')
	STATUS=$(cat /sys/class/power_supply/BAT0/status | tr -d '\n\r ')
	if [ "$Key" -eq -1 ]; then
		if [ "$STATUS" = "Discharging" ]; then
			if [ "$BAT" -eq 30 ]; then
				notify-send -i battery-low " Battery" " Low battery: 30%"
				Key=1
			elif [ "$BAT" -eq 20 ]; then
				Key=1
				notify-send -i battery-caution " Battery"  " Low Battery: 20%"
			elif [ "$BAT" -eq 5 ]; then
				notify-send -i battery-empty " Battery" " Your computer is shutting down soon"
				Key=1
			fi
		fi
		fi

	if [ "$BAT" -ne 30 ] && [ "$BAT" -ne 20 ] && [ "$BAT" -ne 5 ]; then
		Key=-1
	fi
	
done

