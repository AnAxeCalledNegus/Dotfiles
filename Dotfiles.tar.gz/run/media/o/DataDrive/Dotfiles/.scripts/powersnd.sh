if [ $(cat /sys/class/power_supply/BAT0/status |tr -d '\n\r\ ') = "Charging" ] || [ $(cat /sys/class/power_supply/BAT0/status |tr -d '\n\r\ ') = "Notcharging" ] ; then
	Key=-1
else
	Key=1
fi
while true
do
	bS=$(cat /sys/class/power_supply/BAT0/status |tr -d '\n\r\ ')
	sleep 0.15
	if [ "$Key" -eq -1 ]; then	
		if [ "$bS" = "Discharging" ]; then
			/bin/paplay /home/o/Downloads/iosdischarge.mp3
		Key=1
		fi
	elif [ "$Key" -eq 1 ]; then
		if [ "$bS" = "Charging" ]; then
			/bin/paplay /home/o/Downloads/ioscharge.mp3
			Key=-1
		elif [ "$bS" = "Notcharging" ]; then
			/bin/paplay /home/o/Downloads/ioscharge.mp3
			Key=-1
		fi
	fi
done
