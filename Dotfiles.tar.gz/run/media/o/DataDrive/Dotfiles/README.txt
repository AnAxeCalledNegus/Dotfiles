This was made by AnAxeCalledNegus



Disclaimers:
1 *Most things were made by customizing other people's hard work, Most notably the GTK theme.
2 *You are responsible for anything bad that could happen to your system when using my customized themes.
3 *You must configure each file to match whatever paths you choose to execute or launch files from.
4 *Some files need to be copied to their specific paths to function.


#The GTK theme is still a work in progress and is build upon the {{ORIANIN}} Theme :(
#Downloading my configs Makes you fully responsible for anything related to its files' effect on your system

